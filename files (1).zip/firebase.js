import { initializeApp } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";
import {
  getFirestore,
  collection,
  addDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

const firebaseConfig = {
   apiKey: "AIzaSyBmNN2HlG2s80_HrSKxN4bcdC38FEZdATg",
  authDomain: "hang-812ee.firebaseapp.com",
  projectId: "hang-812ee",
  storageBucket: "hang-812ee.firebasestorage.app",
  messagingSenderId: "862446639120",
  appId: "1:862446639120:web:61114e3cd551801ea01295"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// logs every response (yes/no + plan) into a "responses" collection,
// tagged with which creator's link it came from
window.logResponse = async function(data){
  try{
    await addDoc(collection(db, "responses"), {
      ...data,
      createdAt: serverTimestamp()
    });
  }catch(e){
    console.warn("firestore log failed", e);
  }
};
